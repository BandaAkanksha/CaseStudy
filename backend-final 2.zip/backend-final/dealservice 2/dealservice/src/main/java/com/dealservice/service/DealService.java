package com.dealservice.service;

import java.util.List;


import com.dealservice.model.Deal;



//Service interface for dealing with Deal entities
public interface DealService {
    Deal save(Deal deal);
    String deleteById(String id);
    List<Deal> findAll();
    Deal findById(String id);
    Deal updateById(String id, Deal deal);
}


package com.dealservice.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.dealservice.model.Deal;


//Repository interface for dealing with Deal entities in MongoDB
@Repository
public interface DealRepository extends MongoRepository<Deal, String> 
{
     
}

package com.dealservice.model;
import javax.validation.constraints.Min;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//Represents a deal entity stored in MongoDB
@Document(collection = "deals")
public class Deal
{
	// Unique identifier for the deal
	@Id
	@Pattern(regexp = "^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+$", message = "Deals ID must contain both alphabets and numbers")
	private String dealId;
	
	@NotBlank(message="Name cannot be blank")
	private String name;
	
    @Min(value = 1, message = "Price must be greater than 0")
	private int price;
	
    @NotBlank(message="Company name cannot be blank")
	private String companyName;
	
	
	private String imgUrl;
	
	// Constructor with parameters
	public Deal(String dealId, String name, int price, String companyName, String imgUrl) {
		super();
		this.dealId = dealId;
		this.name = name;
		this.price = price;
		this.companyName = companyName;
		this.imgUrl = imgUrl;
	}
	// Default constructor
	public Deal() {
		super();
		// TODO Auto-generated constructor stub
	}
  //Getter Setter Method
	public String getDealId() {
	
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	// Override toString() method to provide a string representation of the Deal object
	@Override
	public String toString() {
		return String.format("Deal[deal Id='%s', name='%s' , price='%s', companyName='%s' ,  imgUrl='%s' ]", dealId,  name,   price,  companyName , imgUrl );
	}

}

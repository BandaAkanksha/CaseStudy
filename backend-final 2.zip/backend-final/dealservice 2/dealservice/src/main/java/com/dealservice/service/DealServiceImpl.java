package com.dealservice.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dealservice.exception.DealAlreadyExistsException;
import com.dealservice.exception.DealNotFoundException;
import com.dealservice.model.Deal;
import com.dealservice.repository.DealRepository;

@Service
public class DealServiceImpl implements DealService {
	// Logger for logging information and errors
	 private static final Logger logger = LoggerFactory.getLogger(DealServiceImpl.class);
    
	// Autowired annotation to inject the DealRepository instance
    @Autowired
    private DealRepository dealRepository;

 // Method to save a new deal
    @Override
    public Deal save(Deal deal) {
        String dealId = deal.getDealId();
        if (dealRepository.existsById(dealId)) {
        	String errorMessage = "Deal with ID " + dealId + " already exists";
            logger.error(errorMessage);
            throw new DealAlreadyExistsException(errorMessage);
        }
        logger.info("Saving new deal with ID: {}", dealId);
        return dealRepository.save(deal);
    }

 // Method to delete a deal by its ID
    @Override
    public String deleteById(String id) {
        Optional<Deal> optionalDeal = dealRepository.findById(id);
        if (!optionalDeal.isPresent()) {
        	String errorMessage = "Deal with ID: " + id + " not found";
            logger.error(errorMessage);
            throw new DealNotFoundException(errorMessage);
        }
        try {
        	// Delete the deal
            dealRepository.deleteById(id);
            logger.info("Deal with ID {} has been deleted", id);
            return "Deal with ID " + id + " has been deleted";
        } catch (Exception e) {
        	String errorMessage = "Failed to delete deal with ID: " + id;
            logger.error(errorMessage, e);
            throw new RuntimeException(errorMessage, e);
        }
    }

    // Method to retrieve all deals
    @Override
    public List<Deal> findAll() {
    	logger.info("Retrieving all deals");
        return dealRepository.findAll();
    }

 // Method to find a deal by its ID
    @Override
    public Deal findById(String id) {
    	logger.info("Finding deal with ID: {}", id);
        Optional<Deal> deal = dealRepository.findById(id);
        if (deal.isPresent()) {
            return deal.get();
        } else {
        	String errorMessage = "Deal with ID " + id + " not found";
            logger.error(errorMessage);
            throw new DealNotFoundException(errorMessage);
        }
    }

 // Method to update a deal by its ID
    @Override
    public Deal updateById(String id, Deal deal) {
        // Check if the deal with the given id exists
        Deal existingDeal = findById(id);
        if (existingDeal == null) {
            // Handle the case where the deal does not exist
        	String errorMessage = "Deal with ID " + id + " not found";
            logger.error(errorMessage);
            throw new DealNotFoundException(errorMessage);
        }
        // Update the existing deal with the new values
        existingDeal.setName(deal.getName());
        existingDeal.setPrice(deal.getPrice());
        existingDeal.setCompanyName(deal.getCompanyName());
        existingDeal.setImgUrl(deal.getImgUrl());
        // Save and return the updated deal
        logger.info("Updating deal with ID: {}", id);
        return dealRepository.save(existingDeal);
    }
}

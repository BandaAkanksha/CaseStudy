package com.dealservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.junit.jupiter.api.BeforeEach;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.mock.mockito.MockBean;

import com.dealservice.model.Deal;
import com.dealservice.repository.DealRepository;
import com.dealservice.service.DealServiceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class DealserviceApplicationTests 
{
    // Autowired instance of DealServiceImpl for testing
    @Autowired
    private DealServiceImpl dealServiceImpl;
     
    // MockBean instance of DealRepository for testing
    @MockBean
    private DealRepository dealRepository;
    
    // Instance of Deal for testing
    Deal deal = new Deal();
    
    // List of Deal objects for testing
    List<Deal> dealList=new ArrayList<Deal>();
    
    
    // Setup method to initialize test data
    @BeforeEach
    public void setup() 
    {
        deal.setDealId("abcd");
        deal.setName("Speakers");
        deal.setPrice(100);
        deal.setCompanyName("Amazon");
        
        dealList.add(deal);
    }
    
    
    // Test method to verify the retrieval of deal details
    @Test
    public void getCouponDetailsTest() {
        Mockito.when(dealServiceImpl.findAll()).thenReturn(dealList);
        assertEquals(1, dealServiceImpl.findAll().size());
    }
    
    
    // Test method to verify the insertion of deal details
    @Test
    public void insertDetailsTest() {
        Mockito.when(dealRepository.save(deal)).thenReturn(deal);
        assertEquals(deal,dealServiceImpl.save(deal));
    }
    
    
    // Test method to verify the retrieval of deal details by ID
    @Test
    public void findByIdTest() {
        Mockito.when(dealRepository.findById("abcd")).thenReturn(Optional.of(deal));
        assertEquals(deal, dealServiceImpl.findById("abcd"));
    }
    
    
    // Test method to verify the deletion of deal details by ID
    @Test
    public void deleteByIdTest() {
        Mockito.when(dealRepository.findById("abcd")).thenReturn(Optional.of(deal));
        dealServiceImpl.deleteById("abcd");
         Mockito.verify(dealRepository, Mockito.times(1)).deleteById("abcd");
    }
}

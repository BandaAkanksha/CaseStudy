package com.dealservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dealservice.exception.DealAlreadyExistsException;
import com.dealservice.exception.DealNotFoundException;
import com.dealservice.model.Deal;
import com.dealservice.repository.DealRepository;

class DealServiceImplTest {
    // Mocked instance of DealRepository
    @Mock
    private DealRepository dealRepository;

    // Instance of DealServiceImpl to be tested, with mocked dependencies injected
    @InjectMocks
    private DealServiceImpl dealService;

    // Setup method to initialize Mockito annotations
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    // Test method to verify the successful saving of a deal
    @Test
    public void testSaveDeal_Success() {
        // Create a new Deal object
        Deal deal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        // Define mock behavior for the existsById and save methods of DealRepository
        when(dealRepository.existsById("1")).thenReturn(false);
        when(dealRepository.save(deal)).thenReturn(deal);

        // Call the save method of DealService
        Deal savedDeal = dealService.save(deal);

        // Assert that the returned Deal object matches the expected one
        assertEquals(deal, savedDeal);
        // Verify that the existsById and save methods of DealRepository are called exactly once
        verify(dealRepository, times(1)).existsById("1");
        verify(dealRepository, times(1)).save(deal);
    }

    // Test method to verify handling of a deal that already exists
    @Test
    public void testSaveDeal_AlreadyExists() {
        // Create a new Deal object
        Deal deal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        // Define mock behavior for the existsById method of DealRepository
        when(dealRepository.existsById("1")).thenReturn(true);

        // Assert that attempting to save the deal throws a DealAlreadyExistsException
        assertThrows(DealAlreadyExistsException.class, () -> {
            dealService.save(deal);
        });

        // Verify that the existsById method of DealRepository is called exactly once, and save is never called
        verify(dealRepository, times(1)).existsById("1");
        verify(dealRepository, never()).save(any(Deal.class));
    }

    // Test method to verify the successful deletion of a deal
    @Test
    public void testDeleteById_Success() {
        // Create a new Deal object
        Deal deal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        // Define mock behavior for the findById method of DealRepository
        when(dealRepository.findById("1")).thenReturn(Optional.of(deal));

        // Call the deleteById method of DealService
        String result = dealService.deleteById("1");

        // Assert that the returned message matches the expected one
        assertEquals("Deal with ID 1 has been deleted", result);
        // Verify that the findById and deleteById methods of DealRepository are called exactly once
        verify(dealRepository, times(1)).findById("1");
        verify(dealRepository, times(1)).deleteById("1");
    }

    // Test method to verify handling of a deal that doesn't exist for deletion
    @Test
    public void testDeleteById_NotFound() {
        // Define mock behavior for the findById method of DealRepository
        when(dealRepository.findById("1")).thenReturn(Optional.empty());

        // Assert that attempting to delete the deal throws a DealNotFoundException
        assertThrows(DealNotFoundException.class, () -> {
            dealService.deleteById("1");
        });

        // Verify that the findById method of DealRepository is called exactly once, and deleteById is never called
        verify(dealRepository, times(1)).findById("1");
        verify(dealRepository, never()).deleteById(anyString());
    }

    // Test method to verify the retrieval of all deals
    @Test
    public void testFindAll() {
        // Create a list of Deal objects
        List<Deal> deals = new ArrayList<>();
        deals.add(new Deal("1", "Test Deal 1", 100, "Test Company", "test1.jpg"));
        deals.add(new Deal("2", "Test Deal 2", 200, "Test Company", "test2.jpg"));
        // Define mock behavior for the findAll method of DealRepository
        when(dealRepository.findAll()).thenReturn(deals);

        // Call the findAll method of DealService
        List<Deal> result = dealService.findAll();

        // Assert that the size and contents of the returned list match the expected values
        assertEquals(deals.size(), result.size());
        assertEquals(deals, result);
        // Verify that the findAll method of DealRepository is called exactly once
        verify(dealRepository, times(1)).findAll();
    }

    // Test method to verify the retrieval of a deal by its ID
    @Test
    public void testFindById_Success() {
        // Create a new Deal object
        Deal deal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        // Define mock behavior for the findById method of DealRepository
        when(dealRepository.findById("1")).thenReturn(Optional.of(deal));

        // Call the findById method of DealService
        Deal result = dealService.findById("1");

        // Assert that the returned Deal object matches the expected one
        assertEquals(deal, result);
        // Verify that the findById method of DealRepository is called exactly once
        verify(dealRepository, times(1)).findById("1");
    }

    // Test method to verify handling of a deal that doesn't exist for retrieval
    @Test
    public void testFindById_NotFound() {
        // Define mock behavior for the findById method of DealRepository
        when(dealRepository.findById("1")).thenReturn(Optional.empty());

        // Assert that attempting to retrieve the deal throws a DealNotFoundException
        assertThrows(DealNotFoundException.class, () -> {
            dealService.findById("1");
        });

        // Verify that the findById method of DealRepository is called exactly once
        verify(dealRepository, times(1)).findById("1");
    }

    // Test method to verify the successful update of a deal
    @Test
    public void testUpdateById_Success() {
        // Create existing and updated Deal objects
        Deal existingDeal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        Deal updatedDeal = new Deal("1", "Updated Deal", 150, "Updated Company", "test.jpg");
        // Define mock behavior for the findById and save methods of DealRepository
        when(dealRepository.findById("1")).thenReturn(Optional.of(existingDeal));
        when(dealRepository.save(existingDeal)).thenReturn(updatedDeal);

        // Call the updateById method of DealService
        Deal result = dealService.updateById("1", updatedDeal);

        // Assert that the returned Deal object matches the updated one
        assertEquals(updatedDeal, result);
        // Verify that the findById and save methods of DealRepository are called exactly once
        verify(dealRepository, times(1)).findById("1");
        verify(dealRepository, times(1)).save(existingDeal);
    }

    // Test method to verify handling of a deal that doesn't exist for updating
    @Test
    public void testUpdateById_NotFound() {
        // Create an updated Deal object
        Deal updatedDeal = new Deal("1", "Updated Deal", 150, "Updated Company", "test.jpg");
        // Define mock behavior for the findById method of DealRepository
        when(dealRepository.findById("1")).thenReturn(Optional.empty());

        // Assert that attempting to update the deal throws a DealNotFoundException
        assertThrows(DealNotFoundException.class, () -> {
            dealService.updateById("1", updatedDeal);
        });

        // Verify that the findById method of DealRepository is called exactly once, and save is never called
        verify(dealRepository, times(1)).findById("1");
        verify(dealRepository, never()).save(any(Deal.class));
    }
}

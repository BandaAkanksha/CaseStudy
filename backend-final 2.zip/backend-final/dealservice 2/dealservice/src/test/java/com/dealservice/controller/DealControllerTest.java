package com.dealservice.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dealservice.model.Deal;
import com.dealservice.service.DealService;

class DealControllerTest {

    // Mocked instance of DealService
    @Mock
    private DealService dealService;

    // Injecting mocked DealService into DealController
    @InjectMocks
    private DealController dealController;

    // Setup method to initialize Mockito annotations
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    // Test method to verify the creation of a deal
    @Test
    public void testCreateDeal() {
        // Create a new Deal object
        Deal deal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        // Define mock behavior for the save method of DealService
        when(dealService.save(any(Deal.class))).thenReturn(deal);

        // Call the createDeal method of DealController
        Deal createdDeal = dealController.createDeal(deal);

        // Assert that the returned Deal object matches the expected one
        assertEquals(deal, createdDeal);
        // Verify that the save method of DealService is called exactly once with any Deal object
        verify(dealService, times(1)).save(any(Deal.class));
    }

    // Test method to verify the retrieval of all deals
    @Test
    public void testGetAllDeals() {
        // Create a list of Deal objects
        List<Deal> deals = Arrays.asList(
                new Deal("1", "Test Deal 1", 100, "Test Company", "test1.jpg"),
                new Deal("2", "Test Deal 2", 200, "Test Company", "test2.jpg"));

        // Define mock behavior for the findAll method of DealService
        when(dealService.findAll()).thenReturn(deals);

        // Call the getAllDeals method of DealController
        List<Deal> result = dealController.getAllDeals();

        // Assert that the size and contents of the returned list match the expected values
        assertEquals(deals.size(), result.size());
        assertEquals(deals, result);
        // Verify that the findAll method of DealService is called exactly once
        verify(dealService, times(1)).findAll();
    }

    // Test method to verify the retrieval of a deal by its ID
    @Test
    public void testGetDealById() {
        // Create a Deal object
        Deal deal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        // Define mock behavior for the findById method of DealService
        when(dealService.findById("1")).thenReturn(deal);

        // Call the getDealById method of DealController
        Deal result = dealController.getDealById("1");

        // Assert that the returned Deal object matches the expected one
        assertEquals(deal, result);
        // Verify that the findById method of DealService is called exactly once with the specified ID
        verify(dealService, times(1)).findById("1");
    }

    // Test method to verify the update of a deal by its ID
    @Test
    public void testUpdateDealById() {
        // Create existing and updated Deal objects
        Deal existingDeal = new Deal("1", "Test Deal", 100, "Test Company", "test.jpg");
        Deal updatedDeal = new Deal("1", "Updated Deal", 150, "Updated Company", "test.jpg");

        // Define mock behavior for the updateById method of DealService
        when(dealService.updateById("1", updatedDeal)).thenReturn(updatedDeal);

        // Call the updateDealById method of DealController
        Deal result = dealController.updateDealById("1", updatedDeal);

        // Assert that the returned Deal object matches the updated one
        assertEquals(updatedDeal, result);
        // Verify that the updateById method of DealService is called exactly once with the specified ID and Deal object
        verify(dealService, times(1)).updateById("1", updatedDeal);
    }
}

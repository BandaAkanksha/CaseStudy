package com.adminsecurity.service;

import com.adminsecurity.exception.AdminAlreadyExistsException;
import com.adminsecurity.exception.AdminNotFoundException;
import com.adminsecurity.exception.AdminUpdateException;
import com.adminsecurity.model.Admin;
import com.adminsecurity.repository.AdminRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

//Implementation of the AdminService interface
@Service
public class AdminServiceImpl implements AdminService {
    private static final Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Find an admin by their ID
    public Admin findById(String id) {
        logger.info("Finding admin with ID: {}", id);
        return adminRepository.findById(id)
                .orElseThrow(() -> {
                    String errorMessage = "Admin not found with id: " + id;
                    logger.error(errorMessage);
                    return new AdminNotFoundException(errorMessage);
                });
    }

    // Add a new admin
    public Admin addAdmin(Admin admin) {
        logger.info("Adding admin with username: {}", admin.getUsername());
        if (adminRepository.existsByUsername(admin.getUsername())) {
            String errorMessage = "Admin with username " + admin.getUsername() + " already exists.";
            logger.error(errorMessage);
            throw new AdminAlreadyExistsException(errorMessage);
        }
        
        // Encrypt the password before saving
        String encryptedPassword = passwordEncoder.encode(admin.getPassword());
        admin.setPassword(encryptedPassword);

        return adminRepository.save(admin);
    }

    // Update an admin by their ID
    public Admin updateById(String id, Admin updatedAdmin) {
        logger.info("Updating admin with ID: {}", id);
        Admin existingAdmin = adminRepository.findById(id)
                .orElseThrow(() -> {
                    String errorMessage = "Admin not found with id: " + id;
                    logger.error(errorMessage);
                    return new AdminNotFoundException(errorMessage);
                });

        // Update the existing admin with the fields from updatedAdmin
        existingAdmin.setUsername(updatedAdmin.getUsername());
        existingAdmin.setPassword(updatedAdmin.getPassword());
        existingAdmin.setName(updatedAdmin.getName());

        // Encrypt the password before saving the updated admin
        String encryptedPassword = passwordEncoder.encode(existingAdmin.getPassword());
        existingAdmin.setPassword(encryptedPassword);

        // Save the updated admin
        return adminRepository.save(existingAdmin);
    }

    // Update an admin
    public Admin updateAdmin(Admin admin) {
        logger.info("Updating admin with ID: {}", admin.getId());
        if (adminRepository.existsById(admin.getId())) {
            // Encrypt the password before saving the updated admin
            String encryptedPassword = passwordEncoder.encode(admin.getPassword());
            admin.setPassword(encryptedPassword);

            return adminRepository.save(admin);
        } else {
            String errorMessage = "Admin update failed. Admin not found with id: " + admin.getId();
            logger.error(errorMessage);
            throw new AdminUpdateException(errorMessage);
        }
    }

    // Delete an admin by their ID
    public void deleteById(String id) {
        logger.info("Deleting admin with ID: {}", id);
        Admin admin = adminRepository.findById(id)
                .orElseThrow(() -> {
                    String errorMessage = "Admin not found with id: " + id;
                    logger.error(errorMessage);
                    return new AdminNotFoundException(errorMessage);
                });
        adminRepository.delete(admin);
    }
}


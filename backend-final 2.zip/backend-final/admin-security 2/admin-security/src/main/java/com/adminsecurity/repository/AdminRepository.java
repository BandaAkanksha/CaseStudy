package com.adminsecurity.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.adminsecurity.model.Admin;


//Repository interface for Admin entities, extending MongoRepository
public interface AdminRepository extends MongoRepository<Admin, String>
{
	// Method to find an Admin by username
	Admin findByUsername(String username);
	// Method to check if an Admin exists by username
	  Boolean existsByUsername(String  username);
	// Method to check if an Admin exists by email
	  Boolean existsByEmail(String email);


}

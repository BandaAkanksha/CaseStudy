package com.adminsecurity.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;


//Represents an Admin entity
@Document(collection = "Admin")
public class Admin 
{
	@Id
	@Pattern(regexp = "^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+$", message = "Admin ID must contain both alphabets and numbers")
	private String id;
	
	@Field
	@NotBlank(message = "Username is required")
	private String username;
	
	@Field
	@NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
	private String email;
	
	@Field
	@NotBlank(message = "Password is required")
    @Size(min = 6, max = 30, message = "Password must be between 6 and 30 characters")
	private String password;
	
	@Field
	@NotBlank(message = "Name is required")
    @Size(max = 100, message = "Name must be less than 100 characters")
	private String name;
	
	// Default constructor 
	public Admin() {
		super();
	}
	
	// Constructor with parameters
	public Admin(String username, String email, String password) {
		super();
		
		this.username = username;
		this.email = email;
		this.password = password;
	}
	
	 // Getters and setters
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

    // ToString method to represent object as string
	@Override
	public String toString() {
		return "Admin [id=" + id + ", username=" + username + ", email=" + email + ", password=" + password + ", name="
				+ name + "]";
	}
	
}

package com.adminservicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.adminsecurity.service.UserDetailsImpl;

public class UserDetailsImplTest {

    @Test
    public void testUserDetailsImpl() {
    	// Test data
        String id = "1";
        String username = "user";
        String email = "user@example.com";
        String password = "password";
        Collection<SimpleGrantedAuthority> authorities = Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"));
        boolean accountNonExpired = true;
        boolean accountNonLocked = true;
        boolean credentialsNonExpired = true;
        boolean enabled = true;
     // Create UserDetailsImpl object
        UserDetailsImpl userDetails = new UserDetailsImpl(id, username, email, password);
     // Assert statements
        assertEquals(id, userDetails.getId());
        assertEquals(username, userDetails.getUsername());
        assertEquals(email, userDetails.getEmail());
        assertEquals(password, userDetails.getPassword());
        
    }
}

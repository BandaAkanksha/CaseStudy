package com.adminsecurity.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
 
import com.adminsecurity.model.Admin;
 
@ExtendWith(MockitoExtension.class)
public class AdminRepositoryTest {
 
    @Mock
    private AdminRepository adminRepository;
 
    @InjectMocks
    private Admin admin;
 
    @BeforeEach
    void setUp() {
        admin = new Admin("testuser", "test@example.com", "password");
    }
 
    @Test
    void testSaveAdmin() {
        when(adminRepository.save(admin)).thenReturn(admin);
 
        Admin savedAdmin = adminRepository.save(admin);
 
        assertEquals(admin.getId(), savedAdmin.getId());
        assertEquals(admin.getUsername(), savedAdmin.getUsername());
        assertEquals(admin.getEmail(), savedAdmin.getEmail());
        assertEquals(admin.getPassword(), savedAdmin.getPassword());
        assertEquals(admin.getName(), savedAdmin.getName());
    }
 
    @Test
    void testFindByUsername() {
        String username = "testuser";
        when(adminRepository.findByUsername(username)).thenReturn(admin);
 
        Admin foundAdmin = adminRepository.findByUsername(username);
 
        assertEquals(admin.getId(), foundAdmin.getId());
        assertEquals(admin.getUsername(), foundAdmin.getUsername());
        assertEquals(admin.getEmail(), foundAdmin.getEmail());
        assertEquals(admin.getPassword(), foundAdmin.getPassword());
        assertEquals(admin.getName(), foundAdmin.getName());
    }
 
    @Test
    void testExistsByUsername() {
        String username = "testuser";
        when(adminRepository.existsByUsername(username)).thenReturn(true);
 
        boolean exists = adminRepository.existsByUsername(username);
 
        assertTrue(exists);
    }
 
    @Test
    void testExistsByEmail() {
        String email = "test@example.com";
        when(adminRepository.existsByEmail(email)).thenReturn(true);
 
        boolean exists = adminRepository.existsByEmail(email);
 
        assertTrue(exists);
    }
}
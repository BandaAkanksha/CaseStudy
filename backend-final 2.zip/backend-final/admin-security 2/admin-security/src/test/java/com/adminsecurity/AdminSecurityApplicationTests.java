package com.adminsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminSecurityApplicationTests {

	// Test method to verify that the Spring application context loads successfully
	@Test
	void contextLoads() {
		// No assertions needed, this test method is used to check if the application context loads without errors
	}
	

}

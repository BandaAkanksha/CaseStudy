package com.adminservicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.adminsecurity.exception.AdminAlreadyExistsException;
import com.adminsecurity.exception.AdminNotFoundException;
import com.adminsecurity.model.Admin;
import com.adminsecurity.repository.AdminRepository;
import com.adminsecurity.service.AdminServiceImpl;

class AdminServiceImplTest {

    @Mock
    private AdminRepository adminRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private AdminServiceImpl adminService;

    @SuppressWarnings("deprecation")
	@BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void findById_AdminExists_ReturnsAdmin() {
        // Arrange
        Admin admin = new Admin("1", "Leesha", "leesha@123");
        when(adminRepository.findById("1")).thenReturn(Optional.of(admin));

        // Act
        Admin foundAdmin = adminService.findById("1");

        // Assert
        assertNotNull(foundAdmin);
        assertEquals(admin.getId(), foundAdmin.getId());
        assertEquals(admin.getUsername(), foundAdmin.getUsername());
        assertEquals(admin.getPassword(), foundAdmin.getPassword());
        assertEquals(admin.getName(), foundAdmin.getName());
    }

    @Test
    void findById_AdminNotExists_ThrowsAdminNotFoundException() {
        // Arrange
        when(adminRepository.findById("1")).thenReturn(Optional.empty());

        // Act and Assert
        assertThrows(AdminNotFoundException.class, () -> adminService.findById("1"));
    }

    @Test
    void addAdmin_NewAdmin_AddsAdmin() {
        // Arrange
        Admin admin = new Admin("2", "Sailabala", "saila@321");
        when(adminRepository.existsByUsername(admin.getUsername())).thenReturn(false);
        when(passwordEncoder.encode(admin.getPassword())).thenReturn("encryptedPassword");
        when(adminRepository.save(any(Admin.class))).thenReturn(admin);

        // Act
        Admin addedAdmin = adminService.addAdmin(admin);

        // Assert
        assertNotNull(addedAdmin);
        assertEquals(admin.getId(), addedAdmin.getId());
        assertEquals(admin.getUsername(), addedAdmin.getUsername());
        assertEquals("encryptedPassword", addedAdmin.getPassword());
        assertEquals(admin.getName(), addedAdmin.getName());
    }

    @Test
    void addAdmin_AdminAlreadyExists_ThrowsAdminAlreadyExistsException() {
        // Arrange
        Admin admin = new Admin("1", "Leesha", "leesha@123");
        when(adminRepository.existsByUsername(admin.getUsername())).thenReturn(true);

        // Act and Assert
        assertThrows(AdminAlreadyExistsException.class, () -> adminService.addAdmin(admin));
    }

    // Similarly, you can write tests for other methods like updateById, updateAdmin, and deleteById
}

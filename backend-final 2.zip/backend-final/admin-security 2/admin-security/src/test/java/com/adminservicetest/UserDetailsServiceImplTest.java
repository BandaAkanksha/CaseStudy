package com.adminservicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.adminsecurity.model.Admin;
import com.adminsecurity.repository.AdminRepository;
import com.adminsecurity.service.UserDetailsServiceImpl;

public class UserDetailsServiceImplTest {

	// Mocked AdminRepository
    @Mock
    private AdminRepository adminRepositoryMock;
 // Injecting mock AdminRepository into UserDetailsServiceImpl
    @InjectMocks
    private UserDetailsServiceImpl userDetailsService;

    // Method to run before each test
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
 // Test case to verify loading user by username
    @Test
    public void testLoadUserByUsername() {
        String username = "user";
        Admin admin = new Admin("1", username, "password");

        when(adminRepositoryMock.findByUsername(username)).thenReturn(admin);

        UserDetails userDetails = userDetailsService.loadUserByUsername(username);

        assertNotNull(userDetails);
        assertEquals(admin.getUsername(), userDetails.getUsername());
    }
 // Test case to verify handling of user not found scenario

    @Test
    public void testLoadUserByUsername_UserNotFound() {
        String username = "nonexistent_user";
     // Mocking behavior of findByUsername method to return null
        when(adminRepositoryMock.findByUsername(username)).thenReturn(null);


    }
}

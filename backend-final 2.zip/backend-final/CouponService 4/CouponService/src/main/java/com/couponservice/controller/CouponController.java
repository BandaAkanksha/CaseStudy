package com.couponservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.couponservice.model.Coupon;
import com.couponservice.service.CouponServiceImpl;



@RestController
@RequestMapping(value="/coupon")
@Validated
@CrossOrigin(origins = "http://localhost:3000")
public class CouponController 
{
	
	@Autowired
	CouponServiceImpl couponService;
	
	// Retrieves a list of all coupons.
	@GetMapping(value="/list")
	public List<Coupon> getCouponDetails() 
	{
		// Call the service to fetch all coupons.
		List<Coupon> list = couponService.findAll();
		return list;
	}
	
	// Finds a coupon by its ID.
	@GetMapping(value = "/findById/{couponId}")
	public ResponseEntity<Coupon> findById(@PathVariable("couponId") String couponId) {
		  // Call the service to find the coupon by ID.
		Coupon coupon = couponService.findByCouponId(couponId);
		 // Check if the coupon exists.
	    if (coupon != null) {
	    	// Return the found coupon with HTTP status OK.
	        return new ResponseEntity<>(coupon, HttpStatus.OK);
	    } else {
	    	 // Return HTTP status NOT_FOUND if the coupon is not found.
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	}
	
	// Deletes a coupon by its ID.
	@DeleteMapping(value="/deleteByCouponId/{couponId}")
	public ResponseEntity<String> deleteById(@PathVariable("couponId") String couponId) 
	{
		// Call the service to delete the coupon by its ID.
		couponService.deleteById(couponId);
		  // Return success message with HTTP status OK.
		return new ResponseEntity<String>("Deleted Successfully", HttpStatus.OK);
	}
	
	// Adds a new coupon.
	@PostMapping(value="/add")
	public ResponseEntity<String> insertDetails(@RequestBody @Valid Coupon coupon) 
	{
		// Call the service to add the new coupon.
		couponService.add(coupon);
		// Return success message with HTTP status OK.
		return new ResponseEntity<String>("Success", HttpStatus.OK);
			
	
    }
	
	// Updates a coupon by its ID.
	@PutMapping("/updateById/{couponId}")
	public ResponseEntity<Coupon> updateCoupon(@PathVariable("couponId") String couponId, @RequestBody Coupon coupon)
	{
		 // Call the service to update the coupon by its ID.
		  Coupon updatedCoupon = couponService.updateCoupon(couponId, coupon);
		  // Return the updated coupon with HTTP status OK.
		  return new ResponseEntity<>(updatedCoupon, HttpStatus.OK);

	}

}

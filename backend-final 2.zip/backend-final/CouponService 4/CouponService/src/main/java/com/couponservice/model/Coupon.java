package com.couponservice.model;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "coupons")
public class Coupon 
{
	@Id
	@Pattern(regexp = "^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+$", message = "Coupon ID must contain both alphabets and numbers")
	private String couponId;
	
	private String category;
	
	@Min(value = 0, message = "Price must be greater than or equal to 0")
	private int price;
	
	private int count;
	private String offer;
	
	private String companyName;
	
	// Custom pattern for date validation, adjust as needed
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Expiry date must be in the format YYYY-MM-DD")
	private String expiryDate;
	
	
	public Coupon() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public int getCount() {
		return count;
	}



	public void setCount(int count) {
		this.count = count;
	}



	public String getCouponId() {
		return couponId;
	}
	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	
	public String getOffer() {
		return offer;
	}
	public void setOffer(String offer) {
		this.offer = offer;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}



	@Override
	public String toString() {
		return "Coupon [couponId=" + couponId + ", category=" + category + ", price=" + price + ", count=" + count
				+ ", offer=" + offer + ", companyName=" + companyName + ", expiryDate=" + expiryDate + "]";
	}



	public Coupon(
			@Pattern(regexp = "^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+$", message = "Coupon ID must contain both alphabets and numbers") String couponId,
			String category, @Min(value = 0, message = "Price must be greater than or equal to 0") int price, int count,
			String offer, String companyName,
			@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Expiry date must be in the format YYYY-MM-DD") String expiryDate) {
		super();
		this.couponId = couponId;
		this.category = category;
		this.price = price;
		this.count = count;
		this.offer = offer;
		this.companyName = companyName;
		this.expiryDate = expiryDate;
	}

	
	
	

}

package com.couponservice.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.couponservice.model.Coupon;
import com.couponservice.service.CouponServiceImpl;

@ExtendWith(MockitoExtension.class)
class CouponControllerTest {

    @Mock
    CouponServiceImpl couponService;

    @InjectMocks
    CouponController couponController;

    // Test method for verifying the retrieval of coupon details.
    @Test
    void testGetCouponDetails() {
        List<Coupon> coupons = new ArrayList<>();
        // Populate coupons list as required for testing
        when(couponService.findAll()).thenReturn(coupons);

        List<Coupon> retrievedCoupons = couponController.getCouponDetails();

        assertEquals(coupons, retrievedCoupons);
    }

    // Test method for verifying the retrieval of a coupon by its ID.
    @Test
    void testFindById() {
        String couponId = "123";
        Coupon coupon = new Coupon();
        // Populate coupon object as required for testing
        when(couponService.findByCouponId(couponId)).thenReturn(coupon);

        ResponseEntity<Coupon> response = couponController.findById(couponId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(coupon, response.getBody());
    }

    // Test method for verifying the case where a coupon is not found by its ID.
    @Test
    void testFindByIdNotFound() {
        String couponId = "123";
        // Mocking service to return null indicating coupon not found
        when(couponService.findByCouponId(couponId)).thenReturn(null);

        ResponseEntity<Coupon> response = couponController.findById(couponId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    // Test method for verifying the deletion of a coupon by its ID.
    @Test
    void testDeleteById() {
        String couponId = "123";
        ResponseEntity<String> expectedResponse = new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
        // Mocking service to perform deletion without exceptions
        doNothing().when(couponService).deleteById(couponId);

        ResponseEntity<String> response = couponController.deleteById(couponId);

        assertEquals(expectedResponse, response);
    }

    // Test method for verifying the insertion of a new coupon.
    @Test
    void testInsertDetails() {
        Coupon coupon = new Coupon();
        
        // Mock the behavior of couponService.add to return "Success" upon successful addition
        when(couponService.add(coupon)).thenReturn(coupon);

        // Call the insertDetails method of the controller
        ResponseEntity<String> response = couponController.insertDetails(coupon);

        // Verify that couponService.add method is called with the correct argument
        verify(couponService).add(coupon);
        
        // Verify that the response entity contains the expected success message and HTTP status
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Success", response.getBody());
    }

    // Test method for verifying the update of an existing coupon.
    @Test
    void testUpdateCoupon() {
        String couponId = "123";
        Coupon coupon = new Coupon();
        ResponseEntity<Coupon> expectedResponse = new ResponseEntity<>(coupon, HttpStatus.OK);
        // Mocking service to perform update without exceptions
        when(couponService.updateCoupon(couponId, coupon)).thenReturn(coupon);

        ResponseEntity<Coupon> response = couponController.updateCoupon(couponId, coupon);

        assertEquals(expectedResponse, response);
    }
}

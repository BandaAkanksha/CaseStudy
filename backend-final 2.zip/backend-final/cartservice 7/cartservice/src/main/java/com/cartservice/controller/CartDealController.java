package com.cartservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cartservice.model.CartDeal;
import com.cartservice.service.CartDealServiceImpl;


@RestController
@RequestMapping(value="/cart/cartdeal")
@CrossOrigin(origins = "http://localhost:3000")
public class CartDealController 
{
	
	
	@Autowired
	CartDealServiceImpl cartDealService;
	
	// Add a new deal
    @PostMapping(value="/add")
    public String addDetails(@Valid @RequestBody CartDeal cartDeal) {
        // Set default quantity to 1
        cartDeal.setQuantity(1);
        // Add the deal
        cartDealService.add(cartDeal);
        return "Success";
    }
	
	// Get all deals
	@GetMapping(value="/list")
	public List<CartDeal> getDealDetails() 
	{	
		// Retrieve and return all deals
		List<CartDeal> list = cartDealService.findAll();
		return list;
		
	}
	
	// Find a deal by ID
	@GetMapping(value = "/findById/{dealId}")
    public CartDeal findById(@PathVariable("dealId") String dealId) {
        // Find the deal by ID
        CartDeal cartDeal = cartDealService.findById(dealId);
        return cartDeal;
    }
	
	// Delete a deal by ID
    @DeleteMapping(value="/deleteById/{dealId}")
    public String deleteById(@PathVariable("dealId") String dealId) {
        // Delete the deal by ID
        cartDealService.deleteById(dealId);
        return "Deleted Successfully";
    }
    
    // Update a deal by ID
    @PutMapping("/updateById/{dealId}")
    public CartDeal updateCoupon(@PathVariable String dealId, @RequestBody CartDeal cartDeal) {
        CartDeal updatedDeal = cartDealService.updateCoupon(dealId, cartDeal);
        return updatedDeal;
    }
    
    // Change quantity of a deal
    @PutMapping("changeQuantity/{dealId}/{quantity}")
    public String changeQuantityDeal(@PathVariable("dealId") String dealId , @PathVariable("quantity") int quantity) {
        cartDealService.changequantity(dealId,quantity);
        return "Quantity updated";
    }
}

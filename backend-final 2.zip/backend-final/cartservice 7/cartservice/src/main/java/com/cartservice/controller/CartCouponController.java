package com.cartservice.controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cartservice.model.CartCoupon;
import com.cartservice.service.CartCouponServiceImpl;
 
@RestController
@RequestMapping(value="/cart/cartcoupon")
@CrossOrigin(origins = "http://localhost:3000")
public class CartCouponController 
{

	@Autowired
	CartCouponServiceImpl cartCouponService;

	// Add a new cart coupon
    @PostMapping(value="/add")
    public String insertDetails(@Valid @RequestBody CartCoupon cartCoupon) {
        // Set default quantity to 1
        cartCoupon.setQuantity(1);
        // Add the cart coupon
        cartCouponService.add(cartCoupon);
        return "Success";
    }
 
	// Get all cart coupons
	@GetMapping(value="/list")
	public List<CartCoupon> getCartCouponDetails() 
	{
		// Retrieve and return all cart coupons
		List<CartCoupon> list = cartCouponService.findAll();
		return list;
	}
	
	// Find a cart coupon by ID
    @GetMapping(value = "/findById/{couponId}")
    public CartCoupon findById(@PathVariable("couponId") String couponId) {
        CartCoupon cartCoupon = cartCouponService.findById(couponId);
        return cartCoupon;
    }
 
    // Delete a cart coupon by ID
    @DeleteMapping(value="/deleteById/{couponId}")
    public String deleteById(@PathVariable("couponId") String couponId) {
        cartCouponService.deleteById(couponId);
        return "Deleted Successfully";
    }
	
    // Update a cart coupon by ID
    @PutMapping("/updateById/{couponId}")
    public CartCoupon updateCoupon(@PathVariable String couponId, @RequestBody CartCoupon cartCoupon) {
        CartCoupon updatedCoupon = cartCouponService.updateCoupon(couponId, cartCoupon);
        return updatedCoupon;
    }
	
    // Change quantity of a cart coupon
    @PutMapping("changeQuantity/{couponId}/{quantity}")
    public String changeQuantityCoupon(@PathVariable("couponId") String couponId , @PathVariable("quantity") int quantity) {
        cartCouponService.changequantity(couponId,quantity);
        return "Quantity updated";
    }
}
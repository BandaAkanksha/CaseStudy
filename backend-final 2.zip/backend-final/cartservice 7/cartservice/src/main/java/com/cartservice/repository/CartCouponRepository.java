package com.cartservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cartservice.model.CartCoupon;

/*
	This creates an interface CartCouponRepository which extends the MongoRepository 
    which an interface provided by Spring Data in the package org.springframework.data.mongodb.repository.
    MongoRepository provides all the necessary methods which help to create a
    CRUD application and it also supports the custom derived query methods.
*/
@Repository
public interface CartCouponRepository extends MongoRepository<CartCoupon, String> 
{
     
}
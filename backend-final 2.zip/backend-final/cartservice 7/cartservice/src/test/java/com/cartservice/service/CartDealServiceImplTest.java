package com.cartservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cartservice.exception.CartDealAlreadyExistsException;
import com.cartservice.exception.CartDealNotFoundException;
import com.cartservice.model.CartDeal;
import com.cartservice.repository.CartDealRepository;

@ExtendWith(MockitoExtension.class)
public class CartDealServiceImplTest {

    @Mock
    private CartDealRepository cartDealRepository;

    @InjectMocks
    private CartDealService cartDealService = new CartDealServiceImpl();

 // Test case for adding a new deal successfully
    @Test
    public void testAddDeal_Success() {
        // Arrange
        CartDeal cartDeal = new CartDeal("123", "Deal Name", 100, "ABC Inc.", "image.jpg", 5);
        when(cartDealRepository.existsById("123")).thenReturn(false);
        when(cartDealRepository.save(cartDeal)).thenReturn(cartDeal);

        // Act
        CartDeal savedDeal = cartDealService.add(cartDeal);

        // Assert
        assertEquals(cartDeal, savedDeal);
    }

    // Test case for adding a deal that already exists
    @Test
    public void testAddDeal_AlreadyExists() {
        // Arrange
        CartDeal cartDeal = new CartDeal("123", "Deal Name", 100, "ABC Inc.", "image.jpg", 5);
        when(cartDealRepository.existsById("123")).thenReturn(true);

        // Act & Assert
        assertThrows(CartDealAlreadyExistsException.class, () -> cartDealService.add(cartDeal));
    }

    // Test case for finding a deal by ID successfully
    @Test
    public void testFindById_Success() {
        // Arrange
        CartDeal cartDeal = new CartDeal("123", "Deal Name", 100, "ABC Inc.", "image.jpg", 5);
        when(cartDealRepository.findById("123")).thenReturn(Optional.of(cartDeal));

        // Act
        CartDeal foundDeal = cartDealService.findById("123");

        // Assert
        assertEquals(cartDeal, foundDeal);
    }

    // Test case for finding a deal by ID when it does not exist
    @Test
    public void testFindById_NotFound() {
        // Arrange
        when(cartDealRepository.findById("123")).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(CartDealNotFoundException.class, () -> cartDealService.findById("123"));
    }

    // Test case for deleting a deal by ID successfully
    @Test
    public void testDeleteById_Success() {
        // Arrange
        String dealId = "123";
        when(cartDealRepository.existsById(dealId)).thenReturn(true);

        // Act & Assert
        assertDoesNotThrow(() -> cartDealService.deleteById(dealId));
    }

    // Test case for deleting a deal by ID when it does not exist
    @Test
    public void testDeleteById_NotFound() {
        // Arrange
        String dealId = "123";
        when(cartDealRepository.existsById(dealId)).thenReturn(false);

        // Act & Assert
        assertThrows(CartDealNotFoundException.class, () -> cartDealService.deleteById(dealId));
    }
}
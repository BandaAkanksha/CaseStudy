package com.customersecurity.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.customersecurity.exception.UserNotFoundException;
import com.customersecurity.model.User;
import com.customersecurity.repository.UserRepository;
import com.customersecurity.service.UserServiceImpl;

class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Test case for retrieving user by email
    @Test
    public void testGetByEmailId() {
        String email = "test@example.com";
        User user = new User();
        user.setEmail(email);

        when(userRepository.getByEmail(email)).thenReturn(user);

        assertEquals(user, userService.getByEmailId(email));
        verify(userRepository, times(1)).getByEmail(email);
    }

    // Test case for retrieving user by email that does not exist
    @Test
    public void testGetByEmailId_UserNotFoundException() {
        String email = "nonexistent@example.com";

        when(userRepository.getByEmail(email)).thenReturn(null);

        assertThrows(UserNotFoundException.class, () -> userService.getByEmailId(email));
        verify(userRepository, times(1)).getByEmail(email);
    }

    // Test case for updating user by email
    @Test
    public void testUpdateByEmail() {
        String email = "test@example.com";
        User existingUser = new User();
        existingUser.setEmail(email);

        User updatedUser = new User();
        updatedUser.setUsername("John Doe");
        updatedUser.setPassword("newPassword");
        updatedUser.setPhone("1234567890");

        when(userRepository.getByEmail(email)).thenReturn(existingUser);
        when(userRepository.save(existingUser)).thenReturn(existingUser);

        assertEquals(existingUser, userService.updateByEmail(email, updatedUser));
        assertEquals(updatedUser.getUsername(), existingUser.getUsername());
        assertEquals(updatedUser.getPassword(), existingUser.getPassword());
        assertEquals(updatedUser.getPhone(), existingUser.getPhone());
        verify(userRepository, times(1)).getByEmail(email);
        verify(userRepository, times(1)).save(existingUser);
    }

    // Test case for updating user by email when user does not exist
    @Test
    public void testUpdateByEmail_UserNotFoundException() {
        String email = "nonexistent@example.com";
        User updatedUser = new User();
        updatedUser.setUsername("John Doe");

        when(userRepository.getByEmail(email)).thenReturn(null);

        assertThrows(UserNotFoundException.class, () -> userService.updateByEmail(email, updatedUser));
        verify(userRepository, times(1)).getByEmail(email);
        verify(userRepository, never()).save(any());
    }

    // Test case for deleting user by email
    @Test
    public void testDeleteByEmailId() {
        String email = "test@example.com";

        when(userRepository.existsByEmail(email)).thenReturn(true);

        assertDoesNotThrow(() -> userService.deleteByEmailId(email));
        verify(userRepository, times(1)).existsByEmail(email);
        verify(userRepository, times(1)).deleteByEmail(email);
    }

    // Test case for deleting user by email when user does not exist
    @Test
    public void testDeleteByEmailId_UserNotFoundException() {
        String email = "nonexistent@example.com";

        when(userRepository.existsByEmail(email)).thenReturn(false);

        assertThrows(UserNotFoundException.class, () -> userService.deleteByEmailId(email));
        verify(userRepository, times(1)).existsByEmail(email);
        verify(userRepository, never()).deleteByEmail(email);
    }
}

package com.customersecurity.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.customersecurity.controller.UserController;
import com.customersecurity.exception.UserNotFoundException;
import com.customersecurity.model.User;
import com.customersecurity.service.UserServiceImpl;

class UserControllerTest {

    @Mock
    private UserServiceImpl userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setup() {
        // Initialize mock objects
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindUserByMail() {
        // Test case for finding a user by email
        String email = "test@example.com";
        User user = new User();
        user.setEmail(email);
        when(userService.getByEmailId(email)).thenReturn(user);

        ResponseEntity<?> response = userController.findUserByMail(email);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(user, response.getBody());
    }

    @Test
    public void testUpdateUserByMail() {
        // Test case for updating a user by email
        String email = "test@example.com";
        User user = new User();
        user.setEmail(email);
        when(userService.updateByEmail(email, user)).thenReturn(user);

        ResponseEntity<?> response = userController.updateUserByMail(email, user);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(user, response.getBody());
    }

    @Test
    public void testDeleteUser() {
        // Test case for deleting a user
        String email = "test@example.com";
        String message = "User deleted successfully";
        when(userService.deleteByEmailId(email)).thenReturn(message);

        ResponseEntity<?> response = userController.deleteUser(email);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(message, response.getBody());
    }

    @Test
    public void testFindUserByMail_UserNotFoundException() {
        // Test case for handling UserNotFoundException when finding a user by email
        String email = "nonexistent@example.com";
        when(userService.getByEmailId(email)).thenThrow(UserNotFoundException.class);

        ResponseEntity<?> response = userController.findUserByMail(email);

        // Assertions
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testUpdateUserByMail_UserNotFoundException() {
        // Test case for handling UserNotFoundException when updating a user by email
        String email = "nonexistent@example.com";
        User user = new User();
        user.setEmail(email);
        when(userService.updateByEmail(email, user)).thenThrow(UserNotFoundException.class);

        ResponseEntity<?> response = userController.updateUserByMail(email, user);

        // Assertions
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testDeleteUser_UserNotFoundException() {
        // Test case for handling UserNotFoundException when deleting a user
        String email = "nonexistent@example.com";
        when(userService.deleteByEmailId(email)).thenThrow(UserNotFoundException.class);

        ResponseEntity<?> response = userController.deleteUser(email);

        // Assertions
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
}

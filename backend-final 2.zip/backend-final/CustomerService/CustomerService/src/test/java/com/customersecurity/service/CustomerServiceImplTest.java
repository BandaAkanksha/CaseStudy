package com.customersecurity.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.customersecurity.exception.CustomerAlreadyExistsException;
import com.customersecurity.exception.CustomerNotFoundException;
import com.customersecurity.model.Customer;
import com.customersecurity.repository.CustomerRepository;
import com.customersecurity.service.CustomerServiceImpl;

class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Test case for adding a customer
    @Test
    public void testAddCustomer() {
        Customer customer = new Customer();
        customer.setCustomerMobile("1234567890");

        when(customerRepository.findByCustomerMobile(customer.getCustomerMobile())).thenReturn(null);
        when(customerRepository.save(customer)).thenReturn(customer);

        assertEquals(customer, customerService.add(customer));
        verify(customerRepository, times(1)).findByCustomerMobile(customer.getCustomerMobile());
        verify(customerRepository, times(1)).save(customer);
    }

    // Test case for adding a customer that already exists
    @Test
    public void testAddCustomer_CustomerAlreadyExistsException() {
        Customer customer = new Customer();
        customer.setCustomerMobile("1234567890");

        when(customerRepository.findByCustomerMobile(customer.getCustomerMobile())).thenReturn(customer);

        assertThrows(CustomerAlreadyExistsException.class, () -> customerService.add(customer));
        verify(customerRepository, times(1)).findByCustomerMobile(customer.getCustomerMobile());
        verify(customerRepository, never()).save(customer);
    }

    // Test case for getting a customer by mobile number
    @Test
    public void testGetByMobile() {
        String mobile = "1234567890";
        Customer customer = new Customer();
        customer.setCustomerMobile(mobile);

        when(customerRepository.findByCustomerMobile(mobile)).thenReturn(customer);

        assertEquals(customer, customerService.getByMobile(mobile));
        verify(customerRepository, times(1)).findByCustomerMobile(mobile);
    }

    // Test case for getting a customer by mobile number that does not exist
    @Test
    public void testGetByMobile_CustomerNotFoundException() {
        String mobile = "1234567890";

        when(customerRepository.findByCustomerMobile(mobile)).thenReturn(null);

        assertThrows(CustomerNotFoundException.class, () -> customerService.getByMobile(mobile));
        verify(customerRepository, times(1)).findByCustomerMobile(mobile);
    }

    // Test case for updating customer details
    @Test
    public void testUpdateCustomer() {
        String mobile = "1234567890";
        Customer existingCustomer = new Customer();
        existingCustomer.setCustomerMobile(mobile);

        Customer updatedCustomer = new Customer();
        updatedCustomer.setCustomerName("John Doe");

        when(customerRepository.findByCustomerMobile(mobile)).thenReturn(existingCustomer);
        when(customerRepository.save(existingCustomer)).thenReturn(existingCustomer);

        assertEquals(existingCustomer, customerService.updateCustomer(mobile, updatedCustomer));
        assertEquals(updatedCustomer.getCustomerName(), existingCustomer.getCustomerName());
        verify(customerRepository, times(1)).findByCustomerMobile(mobile);
        verify(customerRepository, times(1)).save(existingCustomer);
    }

    // Test case for updating customer details when customer does not exist
    @Test
    public void testUpdateCustomer_CustomerNotFoundException() {
        String mobile = "1234567890";
        Customer updatedCustomer = new Customer();
        updatedCustomer.setCustomerName("John Doe");

        when(customerRepository.findByCustomerMobile(mobile)).thenReturn(null);

        assertThrows(CustomerNotFoundException.class, () -> customerService.updateCustomer(mobile, updatedCustomer));
        verify(customerRepository, times(1)).findByCustomerMobile(mobile);
        verify(customerRepository, never()).save(any());
    }

    // Test case for deleting a customer
    @Test
    public void testDeleteCustomer() {
        String mobile = "1234567890";
        Customer existingCustomer = new Customer();
        existingCustomer.setCustomerMobile(mobile);

        when(customerRepository.findByCustomerMobile(mobile)).thenReturn(existingCustomer);

        assertEquals("Deleted Successfully", customerService.deleteCustomer(mobile));
        verify(customerRepository, times(1)).findByCustomerMobile(mobile);
        verify(customerRepository, times(1)).delete(existingCustomer);
    }

    // Test case for deleting a customer that does not exist
    @Test
    public void testDeleteCustomer_CustomerNotFoundException() {
        String mobile = "1234567890";

        when(customerRepository.findByCustomerMobile(mobile)).thenReturn(null);

        assertThrows(CustomerNotFoundException.class, () -> customerService.deleteCustomer(mobile));
        verify(customerRepository, times(1)).findByCustomerMobile(mobile);
        verify(customerRepository, never()).delete(any());
    }
}

package com.customersecurity.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.customersecurity.controller.CustomerController;
import com.customersecurity.exception.CustomerAlreadyExistsException;
import com.customersecurity.exception.CustomerNotFoundException;
import com.customersecurity.model.Customer;
import com.customersecurity.service.CustomerServiceImpl;

class CustomerControllerTest {

    @Mock
    private CustomerServiceImpl customerService;

    @InjectMocks
    private CustomerController customerController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // Test case for adding a customer
    @Test
    public void testAddCustomer() {
        Customer customer = new Customer();
        when(customerService.add(customer)).thenReturn(customer);

        ResponseEntity<Object> response = customerController.addCustomer(customer);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(customer, response.getBody());
    }

    // Test case for getting a customer by mobile number
    @Test
    public void testGetCustomerByMobile() {
        String mobile = "1234567890";
        Customer customer = new Customer();
        when(customerService.getByMobile(mobile)).thenReturn(customer);

        ResponseEntity<Object> response = customerController.getCustomerByMobile(mobile);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(customer, response.getBody());
    }

    // Test case for updating a customer
    @Test
    public void testUpdateCustomer() {
        String mobile = "1234567890";
        Customer updatedCustomer = new Customer();
        when(customerService.updateCustomer(mobile, updatedCustomer)).thenReturn(updatedCustomer);

        ResponseEntity<Object> response = customerController.updateCustomer(mobile, updatedCustomer);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedCustomer, response.getBody());
    }

    // Test case for deleting a customer
    @Test
    public void testDeleteCustomer() {
        String mobile = "1234567890";
        when(customerService.deleteCustomer(mobile)).thenReturn("Customer deleted successfully");

        ResponseEntity<String> response = customerController.deleteCustomer(mobile);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Customer deleted successfully", response.getBody());
    }

    // Test case for handling CustomerAlreadyExistsException when adding a customer
    @Test
    public void testAddCustomerCustomerAlreadyExistsException() {
        Customer customer = new Customer();
        doThrow(CustomerAlreadyExistsException.class).when(customerService).add(customer);

        ResponseEntity<Object> response = customerController.addCustomer(customer);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    // Test case for handling CustomerNotFoundException when getting a customer by mobile number
    @Test
    public void testGetCustomerByMobileCustomerNotFoundException() {
        String mobile = "1234567890";
        doThrow(CustomerNotFoundException.class).when(customerService).getByMobile(mobile);

        ResponseEntity<Object> response = customerController.getCustomerByMobile(mobile);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    // Test case for handling CustomerNotFoundException when updating a customer
    @Test
    public void testUpdateCustomerCustomerNotFoundException() {
        String mobile = "1234567890";
        Customer updatedCustomer = new Customer();
        doThrow(CustomerNotFoundException.class).when(customerService).updateCustomer(mobile, updatedCustomer);

        ResponseEntity<Object> response = customerController.updateCustomer(mobile, updatedCustomer);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    // Test case for handling CustomerNotFoundException when deleting a customer
    @Test
    public void testDeleteCustomerCustomerNotFoundException() {
        String mobile = "1234567890";
        doThrow(CustomerNotFoundException.class).when(customerService).deleteCustomer(mobile);

        ResponseEntity<String> response = customerController.deleteCustomer(mobile);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    } 

}

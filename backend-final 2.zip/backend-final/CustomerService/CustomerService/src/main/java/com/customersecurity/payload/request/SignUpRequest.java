package com.customersecurity.payload.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.mongodb.core.index.Indexed;




public class SignUpRequest
{

	@NotBlank(message = "Username is required")
    @Size(min=3,max = 20, message = "Username must be minimum 3 characters and at most 20 characters")
	private String username;
	@Indexed(unique = true)
	@NotBlank(message = "Email is required")
	@Size(max = 30, message = "Email must be at most 30 characters")
	@Email(message = "Invalid email format")
	@Pattern(regexp = ".*@gmail\\.com$", message = "Email must be a Gmail address")
	private String email;
	
	@NotBlank(message = "Password is required")
	@Size(min = 8, message = "Password must be at least 8 characters")
	private String password;
	@Pattern(regexp = "[6-9]\\d{9}", message = "Phone number must start with a number between 6 to 9 and be 10 digits long")
	private String phone;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	
	

}

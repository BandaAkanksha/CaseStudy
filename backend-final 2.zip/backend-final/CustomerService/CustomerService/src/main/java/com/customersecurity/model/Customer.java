package com.customersecurity.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customer")
public class Customer {

    @Id
    @Pattern(regexp = "^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+$", message = "Customer ID must contain both alphabets and numbers")
    private int customerId;

    @NotBlank(message = "Customer name is required")
    @Size(min = 2, max = 50, message = "Customer name must be between 2 and 50 characters")
    private String customerName;

    @NotBlank(message = "Customer address is required")
    private String customerAddress;

    @NotBlank(message = "Customer card number is required")
    @Pattern(regexp = "\\d{16}", message = "Customer card number must be 16 digits")
    private String customerCardNo;

    @NotBlank(message = "Customer bank name is required")
    private String customerBankName;

    @NotBlank(message = "Customer mobile number is required")
    @Pattern(regexp = "[6-9]\\d{9}", message = "Customer mobile number must be 10 digits and start with a number between 6 to 9")
    private String customerMobile;

    // Default constructor
    public Customer() {
        super();
    }

    // Getters and setters
    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerCardNo() {
        return customerCardNo;
    }

    public void setCustomerCardNo(String customerCardNo) {
        this.customerCardNo = customerCardNo;
    }

    public String getCustomerBankName() {
        return customerBankName;
    }

    public void setCustomerBankName(String customerBankName) {
        this.customerBankName = customerBankName;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    // Parameterized constructor
    public Customer(int customerId, String customerName, String customerAddress, String customerCardNo,
            String customerBankName, String customerMobile) {
        super();
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerCardNo = customerCardNo;
        this.customerBankName = customerBankName;
        this.customerMobile = customerMobile;
    }

    // toString method
    @Override
    public String toString() {
        return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
                + customerAddress + ", customerCardNo=" + customerCardNo + ", customerBankName=" + customerBankName
                + ", customerMobile=" + customerMobile + "]";
    }
}

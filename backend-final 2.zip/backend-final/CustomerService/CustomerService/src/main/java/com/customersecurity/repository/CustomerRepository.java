package com.customersecurity.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.customersecurity.model.Customer;


@Repository
public interface CustomerRepository extends MongoRepository<Customer, Integer>
{
	// Method to find a customer by mobile number
	@Query(value = "{'customerMobile': ?0}")
	Customer findByCustomerMobile(String mobile);
	
	// Method to delete a customer by mobile number
	@Query(value = "{'customerMobile': ?0}", delete = true)
	public void deleteByMobile(String pass_mobile);
	
}
package com.customersecurity.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customersecurity.exception.UserNotFoundException;
import com.customersecurity.model.User;
import com.customersecurity.service.UserServiceImpl;

@RestController
@RequestMapping("/users")
@Validated
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    // Endpoint to find a user by email
    @GetMapping("/findUserByMail/{email}")
    public ResponseEntity<?> findUserByMail(@PathVariable("email") String email) {
        try {
            // Call the service to find user by email
            User user = userServiceImpl.getByEmailId(email);
            return ResponseEntity.ok(user);
        } catch (UserNotFoundException ex) {
            // Handle the case where user is not found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }

    // Endpoint to update a user by email
    @PutMapping("/updateUserByMail/{email}")
    public ResponseEntity<?> updateUserByMail(@PathVariable("email") String email, @RequestBody @Valid User user) {
        try {
            // Call the service to update user by email
            User updatedUser = userServiceImpl.updateByEmail(email, user);
            return ResponseEntity.ok(updatedUser);
        } catch (UserNotFoundException ex) {
            // Handle the case where user is not found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }

    // Endpoint to delete a user by email
    @DeleteMapping("/deleteUser/{email}")
    public ResponseEntity<?> deleteUser(@PathVariable("email") String email) {
        try {
            // Call the service to delete user by email
            String message = userServiceImpl.deleteByEmailId(email);
            return ResponseEntity.ok(message);
        } catch (UserNotFoundException ex) {
            // Handle the case where user is not found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }
}

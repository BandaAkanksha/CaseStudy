package com.customersecurity.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customersecurity.exception.UserAlreadyPresentException;
import com.customersecurity.exception.UserNotFoundException;
import com.customersecurity.model.User;
import com.customersecurity.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserRepository userRepository;
    
     // Retrieves a user by email.

    public User getByEmailId(String email) {
        logger.info("Fetching user by email: {}", email);
        User user = userRepository.getByEmail(email);
        if (user == null) {
            String errorMessage = "User with email " + email + " not found.";
            logger.error(errorMessage);
            throw new UserNotFoundException(errorMessage);
        }
        return user;
    }
    
    //Updates a user with the specified email.

    public User updateByEmail(String email, User updatedUser) {
        logger.info("Updating user by email: {}", email);
        User existingUser = getByEmailId(email);
        existingUser.setUsername(updatedUser.getUsername());
        existingUser.setPassword(updatedUser.getPassword());
        existingUser.setPhone(updatedUser.getPhone());
        return userRepository.save(existingUser);
    }
    //Deletes a user with the specified email.
    
    public String deleteByEmailId(String email) {
        logger.info("Deleting user by email: {}", email);
        if (!userRepository.existsByEmail(email)) {
            String errorMessage = "User with email " + email + " not found.";
            logger.error(errorMessage);
            throw new UserNotFoundException(errorMessage);
        }
        userRepository.deleteByEmail(email);
        return "Deleted Successfully";
    }
}

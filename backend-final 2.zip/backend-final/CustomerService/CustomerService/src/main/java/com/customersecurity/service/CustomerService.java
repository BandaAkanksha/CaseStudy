package com.customersecurity.service;

import com.customersecurity.model.Customer;

public interface CustomerService {
	 // Method to create a new customer
    Customer add(Customer customer);

    // Method to get a customer by mobile number
    Customer getByMobile(String mobile);
    
    //Method to update customer by mobile number
    Customer updateCustomer(String mobile, Customer updatedCustomer);

    // Method to delete a customer by mobile number
    String deleteCustomer(String mobile);
}

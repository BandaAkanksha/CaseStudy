package com.customersecurity.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customersecurity.exception.CustomerAlreadyExistsException;
import com.customersecurity.exception.CustomerNotFoundException;
import com.customersecurity.model.Customer;
import com.customersecurity.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

    private static final Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);

    @Autowired
    private CustomerRepository customerRepository;

    // Method to add a new customer
    public Customer add(Customer customer) {
        logger.info("Adding customer with mobile number: {}", customer.getCustomerMobile());
        // Check if customer with the same mobile number already exists
        if (customerRepository.findByCustomerMobile(customer.getCustomerMobile()) != null) {
            String errorMessage = "Customer with mobile number " + customer.getCustomerMobile() + " already exists.";
            logger.error(errorMessage);
            throw new CustomerAlreadyExistsException(errorMessage);
        }
        // Save the new customer
        return customerRepository.save(customer);
    }

    // Method to get customer by mobile number
    public Customer getByMobile(String mobile) {
        logger.info("Fetching customer by mobile number: {}", mobile);
        // Retrieve customer by mobile number from the repository
        Customer customer = customerRepository.findByCustomerMobile(mobile);
        // If customer is not found, throw CustomerNotFoundException
        if (customer == null) {
            String errorMessage = "Customer with mobile number " + mobile + " not found.";
            logger.error(errorMessage);
            throw new CustomerNotFoundException(errorMessage);
        }
        return customer;
    }

    // Method to update customer details
    public Customer updateCustomer(String mobile, Customer updatedCustomer) {
        logger.info("Updating customer with mobile number: {}", mobile);
        // Retrieve existing customer by mobile number
        Customer existingCustomer = getByMobile(mobile);
        // If customer is not found, throw CustomerNotFoundException
        if (existingCustomer == null) {
            String errorMessage = "Customer with mobile number " + mobile + " not found.";
            logger.error(errorMessage);
            throw new CustomerNotFoundException(errorMessage);
        }
        // Update customer details
        existingCustomer.setCustomerName(updatedCustomer.getCustomerName());
        existingCustomer.setCustomerAddress(updatedCustomer.getCustomerAddress());
        existingCustomer.setCustomerCardNo(updatedCustomer.getCustomerCardNo());
        existingCustomer.setCustomerBankName(updatedCustomer.getCustomerBankName());
        // Save the updated customer
        return customerRepository.save(existingCustomer);
    }

    // Method to delete customer by mobile number
    public String deleteCustomer(String mobile) {
        logger.info("Deleting customer with mobile number: {}", mobile);
        // Retrieve customer by mobile number
        Customer customer = getByMobile(mobile);
        // If customer is not found, throw CustomerNotFoundException
        if (customer == null) {
            String errorMessage = "Customer with mobile number " + mobile + " not found.";
            logger.error(errorMessage);
            throw new CustomerNotFoundException(errorMessage);
        }
        // Delete the customer from repository
        customerRepository.delete(customer);
        return "Deleted Successfully";
    }
}

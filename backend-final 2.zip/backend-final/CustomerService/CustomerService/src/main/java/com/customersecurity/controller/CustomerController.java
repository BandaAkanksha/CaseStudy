package com.customersecurity.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customersecurity.exception.CustomerAlreadyExistsException;
import com.customersecurity.exception.CustomerNotFoundException;
import com.customersecurity.model.Customer;
import com.customersecurity.service.CustomerServiceImpl;

@RestController
@RequestMapping("/customer")
@Validated
@CrossOrigin(origins = "http://localhost:3000")
public class CustomerController {

    @Autowired
    private CustomerServiceImpl customerServiceImpl;

    // Endpoint to add a new customer
    @PostMapping("/addCustomer")
    public ResponseEntity<Object> addCustomer(@RequestBody @Valid Customer customer) {
        try {
            // Call the service to add the customer
            Customer createdCustomer = customerServiceImpl.add(customer);
            return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
        } catch (CustomerAlreadyExistsException e) {
            // Handle the case where the customer already exists
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }

    // Endpoint to get customer by mobile number
    @GetMapping("/getCustomerByMobile/{mobile}")
    public ResponseEntity<Object> getCustomerByMobile(@PathVariable("mobile") String mobile) {
        try {
            // Call the service to get customer by mobile number
            Customer customer = customerServiceImpl.getByMobile(mobile);
            return new ResponseEntity<>(customer, HttpStatus.OK);
        } catch (CustomerNotFoundException e) {
            // Handle the case where customer is not found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // Endpoint to update customer details
    @PutMapping("/updateCustomer/{mobile}")
    public ResponseEntity<Object> updateCustomer(@PathVariable("mobile") String mobile,
                                                  @Valid @RequestBody Customer updatedCustomer) {
        try {
            // Call the service to update customer details
            Customer updated = customerServiceImpl.updateCustomer(mobile, updatedCustomer);
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } catch (CustomerNotFoundException e) {
            // Handle the case where customer is not found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // Endpoint to delete customer by mobile number
    @DeleteMapping("/deleteCustomer/{mobile}")
    public ResponseEntity<String> deleteCustomer(@PathVariable("mobile") String mobile) {
        try {
            // Call the service to delete customer
            String str = customerServiceImpl.deleteCustomer(mobile);
            return new ResponseEntity<>(str, HttpStatus.OK);
        } catch (CustomerNotFoundException e) {
            // Handle the case where customer is not found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}

import React from "react";
import "./Home.css";
import Slider from "./components/Slider";
import Categories from "./components/Categories";

function Home() {
  return (
    <div className="home">
      
     
    </div>
  );
}

export default Home;